// Llamar clases necesarias
const nombre = document.querySelector('.input-nombre');
const correo = document.querySelector('.input-correo');
const contraseña = document.querySelector('.input-contraseña');
const btnEnviar = document.querySelector('.btn-enviar');

// Declarar variable para guardar en el localstorage
const datos = JSON.parse(localStorage.getItem("Usuarios")) || [];

// Funcion para guardar los datos en el localstorage
function guardarDatos (e) {
    e.preventDefault();

    if (nombre.value !== "" && correo.value !== "" && contraseña.value !== "") {
        const nuevoUsuario = {
            nombre: nombre.value,
            correo: correo.value,
            contraseña: contraseña.value
        };

        datos.push(nuevoUsuario);
        localStorage.setItem("Usuarios", JSON.stringify(datos));
        alert("Datos guardados correctamente");

        nombre.value = "";
        correo.value = "";
        contraseña.value = "";

        window.location.href = 'iniciar_sesion.html';
    } else {
        alert("Porfavor rellene todos los datos");
    }
}

// Evento click para guardar los datos
btnEnviar.addEventListener("click", guardarDatos);