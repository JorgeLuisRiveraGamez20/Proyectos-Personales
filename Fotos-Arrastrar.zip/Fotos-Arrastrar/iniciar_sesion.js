// Llamamos clases necesarias
const email = document.querySelector('.input-correo');
const password = document.querySelector('.input-contraseña');
const btnSubmit = document.querySelector('.btn-enviar');

const data = JSON.parse(localStorage.getItem("Usuarios")) || [];

// Funcion para verificar que el usuario este registrado
function iniciarSesion (e) {
    e.preventDefault();

    const usuarioEncontrado = data.find(users => 
        users.correo == email.value && users.contraseña == password.value
    )

    if (usuarioEncontrado) {
        alert("Tus datos son correctos");
        window.location.href = 'index.html';x
    } else {
        alert("Correo o contraseña son incorrectos o no han sido registrados");
    }
}

// Evento click para iniciar sesion
btnSubmit.addEventListener('click', iniciarSesion);