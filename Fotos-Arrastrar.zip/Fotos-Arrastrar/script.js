// Llamamos clases necesarias
const contenedor = document.querySelector('.contenedor-imagenes');
const archivo = document.querySelector('.archivo');

// Funcion para cargar imagenes
function generarImagen(evento) {
    evento.preventDefault();

    const imagen = archivo.files[0];

    if (imagen && imagen.type.startsWith("image")) {
        const lector = new FileReader();

        lector.onload = function (e) {
            const urlImagen = e.target.result;

            const img = document.createElement("img");
            img.src = urlImagen;
            img.classList.add("imagen");

            contenedor.appendChild(img);
        }

        lector.readAsDataURL(imagen);
    }
}

// Evento para cargar una imagen
archivo.addEventListener("change", generarImagen);