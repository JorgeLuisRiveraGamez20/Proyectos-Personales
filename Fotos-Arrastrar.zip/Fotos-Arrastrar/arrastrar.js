// Seleccionamos las clases necesarias
const imagenes = document.querySelectorAll('.imagen');
const zonaArrastre = document.querySelector('.zona-arrastre');

// Evento para cuando se inicia arrastrar
imagenes.forEach(imagen => {
    imagen.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', e.target.src); 
    });
});

// Evento para permitir mover la imagen
zonaArrastre.addEventListener('dragover', (e) => {
    e.preventDefault(); 
});

// Evento para soltar la imagen
zonaArrastre.addEventListener('drop', (e) => {
    e.preventDefault();
    const src = e.dataTransfer.getData('text/plain'); 
    const nuevaImagen = document.createElement('img');
    nuevaImagen.classList.add('imagen-arrastrada'); 
    nuevaImagen.src = src; 
    zonaArrastre.appendChild(nuevaImagen); 
});

