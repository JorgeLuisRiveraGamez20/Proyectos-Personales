// Llamar las clases necesarias
const inputBuscador = document.querySelector('.input-buscar');
const contenedorBusqueda = document.querySelector('.contenedor-busqueda');
const buscar2 = document.querySelector('.btn-buscar');
const contenedorOriginal = document.querySelector('.contenedor-tarjetas');

// Función para buscar las tarjetas por nombres
function buscarPersona() {
    const buscador = inputBuscador.value.toLowerCase();

    if (buscador !== "") {
        contenedorBusqueda.innerHTML = ""; 
        const tarjetas = document.querySelectorAll('.tarjeta');

        tarjetas.forEach(tarjeta => {
            const nombreElemento = tarjeta.querySelector('.nombre-tarjeta');

            if (nombreElemento) {
                const titulo = nombreElemento.textContent.toLowerCase();

                if (titulo.includes(buscador)) {
                    const clon = tarjeta.cloneNode(true);
                    contenedorBusqueda.appendChild(clon);
                }
            }
        });
    } else {
        alert("Input vacío");
    }
}

// Evento para buscar persona
buscar2.addEventListener('click', buscarPersona);
