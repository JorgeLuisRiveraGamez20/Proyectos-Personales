// LLamar a las clases necesarias
const nombre = document.querySelector('.input-nombre');
const profesion = document.querySelector('.input-profesion');
const descripcion = document.querySelector('.textarea-descripcion');
const boton = document.querySelector('.btn-generar');
const archivo = document.querySelector('.archivo');
const contenedor = document.querySelector('.contenedor-tarjetas');

// Variable para guardar en localstorage
let personas = JSON.parse(localStorage.getItem("listaPersonas")) || [];

// Funcion para agregar las tarjetas y funcionen los inputs y carguen las imagenes
function crearTarjeta(evento) {
    evento.preventDefault(); 

    const imagen = archivo.files[0];

    if (
        imagen &&
        imagen.type.startsWith("image/") &&
        nombre.value !== "" &&
        profesion.value !== "" &&
        descripcion.value !== ""
    ) {
        const reader = new FileReader();
        reader.onload = function (e) {
            const persona = {
                nombre: nombre.value,
                profesion: profesion.value,
                descripcion: descripcion.value,
                imagen: e.target.result
            };

            // Crear elemento para la tarjeta
            const tarjeta = document.createElement("div");
            tarjeta.classList.add('tarjeta');
            
            // Configuración de elemento para eliminar
            const btnEliminar = document.createElement('button');
            btnEliminar.textContent = 'X';
            btnEliminar.classList.add('btn-eliminar');

            // Agregar elementos
            tarjeta.innerHTML = `
                <img class="imagen-tarjeta" src="${persona.imagen}" alt="Imagen">
                <h3 class="nombre-tarjeta">${persona.nombre}</h3>
                <p class="profesion-tarjeta">${persona.profesion}</p>
                <p class="descripcion-tarjeta">${persona.descripcion}</p>
            `;

            tarjeta.appendChild(btnEliminar);
            contenedor.appendChild(tarjeta);

            // Añdimos a el localstorage
            personas.push(persona);
            localStorage.setItem("listaPersonas", JSON.stringify(personas));

            // Evento para eliminar la tarjeta y del localstorage
            btnEliminar.addEventListener('click', () => {
                contenedor.removeChild(tarjeta);
                personas = personas.filter(p =>
                    !(p.nombre === persona.nombre &&
                      p.descripcion === persona.descripcion &&
                      p.profesion === persona.profesion &&
                      p.imagen === persona.imagen)
                );
                localStorage.setItem("listaPersonas", JSON.stringify(personas));
            });

            // Limpiar campos
            nombre.value = "";
            profesion.value = "";
            descripcion.value = "";
            archivo.value = "";
        };
        reader.readAsDataURL(imagen);
    } else {
        alert("Llena todos los campos y selecciona una imagen.");
    }
}

// Evento para cuando demos click se agregue la tarjeta
boton.addEventListener('click', crearTarjeta);