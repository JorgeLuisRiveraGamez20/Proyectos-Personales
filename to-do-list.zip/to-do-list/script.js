// Llamar clases necesarias
const input = document.querySelector('.input');
const agregar = document.querySelector('.btn-agregar');
const tareas = document.querySelector('.contenedor-tareas');

function agregarEliminarTareas() {
    if (input.value !== "") {
        // Crear elementos
        const nuevaTarea = document.createElement('li');
        const check = document.createElement('input');
        const eliminar = document.createElement('img');

        // Añadir clase y texto a la tarea
        nuevaTarea.classList.add('mi-tarea');
        nuevaTarea.textContent = input.value;

        // Guardar en localStorage 
        localStorage.setItem("tarea", input.value);
        localStorage.getItem("tarea", input.value);
        alert("Tarea agregada correctamente");

        // Configurar el checkbox
        check.type = 'checkbox';
        check.classList.add('check');

        // Configurar botón eliminar
        eliminar.src = 'img/eliminar.png';
        eliminar.alt = 'Eliminar';
        eliminar.width = 20;
        eliminar.height = 20;
        eliminar.classList.add('btn-eliminar');

        // Evento click para eliminar tarea
        eliminar.addEventListener('click', () => {
            const confirmar = confirm("¿Realmente deseas eliminar esta tarea?");
            if (!confirmar) return;
            nuevaTarea.remove();
            localStorage.removeItem("tarea");
            alert("Tarea eliminada correctamente");
        });

        // Agregar elementos a la tarea
        nuevaTarea.textContent = input.value;
        nuevaTarea.appendChild(check);
        nuevaTarea.appendChild(eliminar);

        // Agregar tarea al contenedor
        tareas.appendChild(nuevaTarea);
        nuevaTarea.style.overflow = 'auto';

        // Limpiar input
        input.value = "";
    } else {
        alert("Input vacío, digita algo para agregar");
    }
}

agregar.addEventListener('click', agregarEliminarTareas);


// Llamar clases necesarias 
const blanco = document.querySelector('.btn-blanco');
const negro = document.querySelector('.btn-negro');
const body = document.querySelector('body');
const contenedor = document.querySelector('.contenedor');
const titulo = document.querySelector('.titulo');
const contenedorTareas = document.querySelector('.contenedor-tareas');

// Funcion para hacer modo oscuro la app
function modoOscuro() {
    body.style.background = '#000';
    contenedor.style.background = '#000';
    titulo.style.color = '#fff';
    contenedorTareas.style.background = '#000';
}

// Funcion para hacer modo claro la app
function modoClaro() {
    body.style.background = '#fff';
    contenedor.style.background = '#fff';
    titulo.style.color = '#000';
    contenedorTareas.style.background = '#fff';
}

// Evento click para que funcione
negro.addEventListener('click', modoOscuro);
blanco.addEventListener('click', modoClaro);