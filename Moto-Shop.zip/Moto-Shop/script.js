const comprar1 = document.querySelectorAll('.btn-comprar');

comprar1.forEach(bototn => {
    bototn.addEventListener('click', dirigiFormulario);
        function dirigiFormulario() {
            window.location.href = 'formulario.html';
        }
});





const correo1 = document.querySelector('.input-email');
const mensaje1 = document.querySelector('.textarea-mensaje');
const enviar1 = document.querySelector('.btn-enviar');

function mensajeContacto() {
    if (correo1.value !== "" && mensaje1.value !== "") {
        alert("Tu mensaje ha sido enviado a nuestro correo");
    }
}

enviar1.addEventListener('click', mensajeContacto);





