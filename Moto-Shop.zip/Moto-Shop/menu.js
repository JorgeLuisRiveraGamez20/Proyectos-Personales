const menuHamburguesa = document.querySelector('.img-hamburguesa');
const contenedorMenu = document.querySelector('.contenedor-menu');
const btnCerrar = document.querySelector('.btn-cerrar-menu');

function abrirMenu() {
    contenedorMenu.style.right = '0'; 
}

function cerrarMenu() {
    contenedorMenu.style.right = '-100%'; 
}

menuHamburguesa.addEventListener('click', abrirMenu);
btnCerrar.addEventListener('click', cerrarMenu);


