const mayorEdad = document.querySelector('.input-edad');
const botonEnviar = document.querySelector('.enviar-datos');
const inputTarjeta = document.querySelector('.input-tarjeta'); 

function enviarDatos(event) {
    if (mayorEdad.value < 18) {
        alert("No se permite realizar compras a menores de edad");
        event.preventDefault(); 
    } else if (inputTarjeta.value.length < 16 || inputTarjeta.value.length > 16) {
        alert("El numero de tarjeta debe ser igual a 16 digitos");
        event.preventDefault(); 
    }
}

botonEnviar.addEventListener('click', enviarDatos);




