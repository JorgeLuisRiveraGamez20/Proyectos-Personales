// Llamar a los id necesarias
const flechaIzq = document.getElementById('flecha-izquierda');
const flechaDer = document.getElementById('flecha-derecha');
const carrusel = document.getElementById('carrusel');

// Funcion para mover el carrusel
function moverCarrusel(evento) {
    const scrollCantidad = 270;

    if (evento.target.id === 'flecha-izquierda') {
        carrusel.scrollLeft -= scrollCantidad;
    } else if (evento.target.id === 'flecha-derecha') {
        carrusel.scrollLeft += scrollCantidad;
    }
}

// Eventos de clic con función directa
flechaIzq.addEventListener('click', moverCarrusel);
flechaDer.addEventListener('click', moverCarrusel);




// Llamar a las clases necesarias
const input = document.querySelector('.input-buscador');
const botonBuscar = document.querySelector('.btn-buscar');
const recetas = document.querySelectorAll('.contenedor-imagen');
const contenedorResultados = document.querySelector('.contenedor-recetas-buscador');

// Funcion de búsqueda
function buscarRecetas() {
    if (input.value !== "") {
        const buscador = input.value.toLowerCase();
        contenedorResultados.textContent = "";

        recetas.forEach(receta => {
            const titulo = receta.querySelector('.titulo-receta').textContent.toLowerCase();

            if (titulo.includes(buscador)) {
                const clon = receta.cloneNode(true);
                contenedorResultados.appendChild(clon);
            }
        })
    } else {
        alert("Input vacio");
    }
}

// Agregar evento click al boton
botonBuscar.addEventListener('click', buscarRecetas);